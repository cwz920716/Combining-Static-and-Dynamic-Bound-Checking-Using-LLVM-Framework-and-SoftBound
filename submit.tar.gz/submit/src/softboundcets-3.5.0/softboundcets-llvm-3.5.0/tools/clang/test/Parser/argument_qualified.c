// RUN: %clang_cc1 %s
int abc (const float x) {
  return 1;
}

