/// Comment for 'functionFromDocCommentsA1'.
void functionFromDocCommentsA1(void);

#import <DocCommentsC/DocCommentsC.h>

/// Comment for 'functionFromDocCommentsA2'.
void functionFromDocCommentsA2(void);

