@interface I {
  struct AA {
    int x;
  } aa;
  int var;
}
-(id)foo;
@end
