struct S {
  #include "b2.h"
};
