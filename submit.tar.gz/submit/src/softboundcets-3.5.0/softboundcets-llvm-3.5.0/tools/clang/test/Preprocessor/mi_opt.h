#if !defined foo MACRO
#define foo
int x = 2;
#endif
