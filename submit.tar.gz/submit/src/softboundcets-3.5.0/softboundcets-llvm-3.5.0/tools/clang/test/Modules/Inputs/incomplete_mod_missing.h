extern int *missing;

