#ifndef A_H
#define A_H
const int a = 2;
#endif
