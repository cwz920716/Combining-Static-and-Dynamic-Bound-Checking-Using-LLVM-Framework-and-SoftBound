typedef int Int;
void f0(Int);
void f1(Int, double);
void f2(int, int);
void f3(int);
static void f4(float, float);
int f5(int) __attribute__((const));
