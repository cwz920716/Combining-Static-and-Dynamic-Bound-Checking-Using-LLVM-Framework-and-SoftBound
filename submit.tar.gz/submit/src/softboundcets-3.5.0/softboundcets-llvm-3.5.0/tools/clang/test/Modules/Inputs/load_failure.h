int fail(int);
