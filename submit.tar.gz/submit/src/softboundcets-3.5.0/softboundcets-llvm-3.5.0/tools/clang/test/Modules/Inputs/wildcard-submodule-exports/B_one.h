short *B1;
