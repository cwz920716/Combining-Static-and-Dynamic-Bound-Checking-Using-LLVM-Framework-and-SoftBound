int no_umbrella_C;
