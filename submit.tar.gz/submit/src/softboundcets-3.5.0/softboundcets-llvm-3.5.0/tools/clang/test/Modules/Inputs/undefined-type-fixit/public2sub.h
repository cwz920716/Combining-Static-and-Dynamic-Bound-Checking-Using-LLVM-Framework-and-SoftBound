#ifndef PUBLIC2SUB_H
#define PUBLIC2SUB_H

struct use_this2sub { int field; };

#endif
