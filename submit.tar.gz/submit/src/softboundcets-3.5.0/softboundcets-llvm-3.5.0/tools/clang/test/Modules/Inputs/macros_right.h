@import macros_top;
#define RIGHT unsigned short








#define LEFT_RIGHT_IDENTICAL int
#define LEFT_RIGHT_DIFFERENT int
#define LEFT_RIGHT_DIFFERENT2 int
#define LEFT_RIGHT_DIFFERENT3 int

#undef TOP_RIGHT_REDEF
#define TOP_RIGHT_REDEF float

#define FN_ADD(x, y) (x+y)

#undef TOP_OTHER_DEF_RIGHT_UNDEF
