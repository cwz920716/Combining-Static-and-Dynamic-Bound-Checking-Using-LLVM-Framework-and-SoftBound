// RUN: %clang_cc1 -emit-llvm %s  -o /dev/null


const char *W = "foo";
const int X = 7;
int Y = 8;
const char * const Z = "bar";

