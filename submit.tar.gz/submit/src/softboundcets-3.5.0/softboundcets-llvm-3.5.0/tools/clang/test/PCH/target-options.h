enum { apple_cc = __APPLE_CC__ };

