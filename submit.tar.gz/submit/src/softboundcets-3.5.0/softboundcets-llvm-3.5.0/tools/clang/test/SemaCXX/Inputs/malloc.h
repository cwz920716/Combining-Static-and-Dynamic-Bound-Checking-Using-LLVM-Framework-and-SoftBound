extern "C" {
extern void *malloc (__SIZE_TYPE__ __size) throw () __attribute__ ((__malloc__)) ;
}
