// RUN: %clang_cc1 -fsyntax-only %s

bool a = true;
bool b = false;
