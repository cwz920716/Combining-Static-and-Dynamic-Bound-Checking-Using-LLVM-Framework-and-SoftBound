struct Point {
  double x, y;
};

#ifdef IGNORED
int *has_ignored(void);
#endif

