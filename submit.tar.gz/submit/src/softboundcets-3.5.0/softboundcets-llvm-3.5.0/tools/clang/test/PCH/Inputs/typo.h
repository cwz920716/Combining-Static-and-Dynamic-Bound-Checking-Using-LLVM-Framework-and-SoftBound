

@interface NSString
+ (id)alloc;
@end

