// Header for PCH test pragma-weak.c

#pragma weak weakvar






#pragma weak undeclaredvar
