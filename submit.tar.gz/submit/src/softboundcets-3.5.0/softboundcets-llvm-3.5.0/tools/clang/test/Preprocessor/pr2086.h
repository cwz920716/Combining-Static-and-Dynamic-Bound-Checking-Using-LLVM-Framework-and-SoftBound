#ifndef test
#endif

#ifdef test
#undef test
#endif
